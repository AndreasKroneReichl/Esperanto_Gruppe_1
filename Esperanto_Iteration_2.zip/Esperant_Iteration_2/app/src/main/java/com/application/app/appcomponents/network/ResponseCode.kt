package com.application.app.appcomponents.network

object ResponseCode {
    const val OK = 200
}